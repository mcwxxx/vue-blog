<!--
 * @Author: masi 2454023350@qq.com
 * @Date: 2025-06-25 15:32:00
 * @LastEditors: masi 2454023350@qq.com
 * @LastEditTime: 2025-06-25 15:32:16
 * @FilePath: \figmamcp\vue-blog\src\views\About.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-4">关于我们</h1>
    <div class="prose max-w-none">
      <p>这是一个使用Vue3、Vite和TailwindCSS构建的个人博客项目。</p>
      <p class="mt-4">项目特点：</p>
      <ul class="list-disc pl-6 mt-2">
        <li>响应式设计</li>
        <li>现代化的UI</li>
        <li>高效的前端架构</li>
      </ul>
    </div>
  </div>
</template>
